# Claude handoff — compact source package

This compact archive intentionally contains only the 15 source/configuration files needed to recreate the full Core Builds Icon Pack v1.6.0 change. Generated SVG, PNG, XML, and preview files were omitted to make the download reliable.

Repository: `https://github.com/brevityA/CoreBuildsApps`
Base branch: `main`
Target version: `1.6.0`, version code `9`

## Apply

1. Clone/open the repository and update `main`.
2. Create a feature branch.
3. Copy every repository file from this archive into the repository root, preserving paths and overwriting existing files.
4. Do not copy this handoff note or `INCLUDED_SOURCE_FILES.txt` into the repository.
5. Install and regenerate all omitted outputs:

```bash
python -m pip install -r tools/requirements.txt
python tools/build_icons.py
python tools/build_banners.py
```

These commands generate all square icons, banners, appfilter files, picker XML, icon metadata, supported-app documentation, and previews from `tools/catalog.json`.

## Validate

```bash
python tools/validate.py
python tests/test_v151_robustness.py
git diff --check
```

Expected:

- 917 icons
- 1,090 source components
- 1,646 generated appfilter rows
- 958 packages
- 24 tests pass
- validator passes

Confirm release policy:

```bash
grep -n "make_latest" .github/workflows/build.yml .github/workflows/core-line-apk.yml
```

Expected: icon-pack versioned release `true`; iconpack floating release `false`; both Core Line entries `false`.

## Commit and PR

Commit every copied and generated file, push the feature branch, and open a PR against `main` titled:

`Expand icon pack to 917 apps and add stable Downloader release`

The GitHub credential must have permission to update `.github/workflows/build.yml`.

## After merge

Only after the workflow is on `main`, seed the stable release:

```bash
rm -rf /tmp/iconpack && mkdir -p /tmp/iconpack
gh release download v1.5.1 --repo brevityA/CoreBuildsApps --pattern '*.apk' --dir /tmp/iconpack
SRC=$(find /tmp/iconpack -maxdepth 1 -name '*.apk' | head -1)
cp "$SRC" /tmp/iconpack/iconpack-release.apk
cp "$SRC" /tmp/iconpack/app-release.apk

git fetch origin --tags
git tag -f iconpack v1.5.1
git push -f origin refs/tags/iconpack

gh release create iconpack \
  /tmp/iconpack/iconpack-release.apk \
  /tmp/iconpack/app-release.apk \
  --repo brevityA/CoreBuildsApps \
  --title "Icon Pack (latest)" \
  --notes "Stable Downloader target. 5270601 uses latest/app-release.apk." \
  --latest=false

gh release edit v1.5.1 --repo brevityA/CoreBuildsApps --latest
```

If `iconpack` already exists, use `gh release upload iconpack ... --clobber` instead of `gh release create`.

Verify:

```bash
curl -sI -L --max-redirs 0 https://github.com/brevityA/CoreBuildsApps/releases/download/iconpack/iconpack-release.apk
curl -sI -L --max-redirs 6 https://github.com/brevityA/CoreBuildsIconPack/releases/latest/download/app-release.apk
```

Forever URL:
`https://github.com/brevityA/CoreBuildsApps/releases/download/iconpack/iconpack-release.apk`
